package com.revature.presentation;

import java.util.Scanner;

import org.apache.log4j.Logger;

public class BankTerminal {

	public static void main(String[] args) {
		
		final Logger bankLog = Logger.getLogger(BankTerminal.class);
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
		bankLog.info("Welcome to BANK");
		bankLog.info("Would you like to sign in or create an account? Please enter the number of your selection");
		bankLog.info("1) Sign in");
		bankLog.info("2) Create account");
		
		switch(sc.nextInt()){
		case 1:
			bankLog.info("Are you an employee or a customer?");
			bankLog.info("1) Employee");
			bankLog.info("2) Customer");			
			switch(sc.nextInt()) {
			case 1:
				System.out.println("Please enter your username");
				String eUser = sc.nextLine();
				System.out.println("And your password");
				String ePass = sc.nextLine();
				
				System.out.println("Welcome. What would you like to do?");
				System.out.println("1) Approve or deny an account");
				System.out.println("2) View a customer account");
				System.out.println("3) View all customer accounts");
				break;
			case 2:
				System.out.println("2");
				break;
			default: 
				bankLog.info("This is not a valid response. Please enter the number of your selection");
			}
			break;
		case 2:
						
			System.out.print("Enter your first name ");
			String firstName = sc.nextLine();
			
			System.out.println("and your last name");
			String lastName = sc.nextLine();
			
			System.out.println("Welcome, " + firstName + " " + lastName + ". Please enter a username. You will use this to log in.");
			String username = sc.nextLine();
			
			System.out.println("Choose a password");
			String password = sc.nextLine();
			
			System.out.println("Enter your street address");
			String address = sc.nextLine();
			
			System.out.println("Enter your city");
			String city = sc.nextLine();
			
			System.out.println("Enter your state");
			String state = sc.nextLine();
			
			System.out.println("Enter your phone number");
			String phone = sc.nextLine();
			
			System.out.println("Your user account has been created! Please log in.");
			break;
		default:
			bankLog.info("That is not a valid selection. Please try again.");
			break;
		}
		}

	}

}
