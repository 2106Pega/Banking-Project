package com.revature.models;

public class Account {
	
	private String customerId;
	private boolean checking;
	private boolean savings;
	private int accountId;
	public Account() {
		super();
	}
	public Account(String customerId, boolean checking, boolean savings, int accountId) {
		super();
		this.customerId = customerId;
		this.checking = checking;
		this.savings = savings;
		this.accountId = accountId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public boolean isChecking() {
		return checking;
	}
	public void setChecking(boolean checking) {
		this.checking = checking;
	}
	public boolean isSavings() {
		return savings;
	}
	public void setSavings(boolean savings) {
		this.savings = savings;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountId;
		result = prime * result + (checking ? 1231 : 1237);
		result = prime * result + ((customerId == null) ? 0 : customerId.hashCode());
		result = prime * result + (savings ? 1231 : 1237);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountId != other.accountId)
			return false;
		if (checking != other.checking)
			return false;
		if (customerId == null) {
			if (other.customerId != null)
				return false;
		} else if (!customerId.equals(other.customerId))
			return false;
		if (savings != other.savings)
			return false;
		return true;
	}

}
