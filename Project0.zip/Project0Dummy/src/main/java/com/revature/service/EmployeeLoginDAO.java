package com.revature.service;

public interface EmployeeLoginDAO {

}
