package com.revature.service;

import java.util.Scanner;

import org.apache.log4j.Logger;

public class CreateCustomerAccount {
	
	Logger logger = Logger.getLogger(CreateCustomerAccount.class);
	Scanner sc = new Scanner(System.in);
	
	
	

}
